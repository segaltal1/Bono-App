import {useTranslation} from "react-i18next";
import {useContext} from "react";
import {onSessionConnected, web3Modal} from "../../../Helpers/eth";
import {AppContext} from "../../../MainContext/AppContext";


export const ConnectWalletButton = () => {
    const {t} = useTranslation()

    const {
        signClient,
        setSession,
        setChain,
        setProvider,
        setAccount
    } = useContext(AppContext);


    const handleConnectWallet = async () => {
        if (!signClient) throw Error('Client is not set');

        try {
            const {uri, approval} = await signClient.connect({
                requiredNamespaces: {
                    eip155: {
                        methods: ['eth_sendTransaction', 'eth_signTransaction', 'personal_sign', 'eth_maxPriorityFeePerGas'],
                        chains: ['eip155:56'],
                        events: ['connect', 'disconnect'],
                    },
                },
                specialNamespaces: {
                    wallet: {
                        methods: ['wallet_switchEthereumChain'],
                        events: [],
                    },
                },
            });

            if (uri) {
                web3Modal.openModal({uri});
                const sessionNamespace = await approval();
                setSession(sessionNamespace);
                const {chain, provider, account} = onSessionConnected(sessionNamespace);
                setChain(chain);
                setProvider(provider);
                setAccount(account);
                localStorage.setItem('session', JSON.stringify(sessionNamespace));
                web3Modal.closeModal();
            }
        } catch (e) {
            console.log(e);
        }
    }


    return (
        <div  className="connect button truncate iframe" onClick={handleConnectWallet}>
            Connect Wallet
        </div>
    );
};
