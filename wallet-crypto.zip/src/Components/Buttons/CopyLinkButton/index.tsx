import {copyToClipboard} from "../../../Helpers/utils";
import React, {useState} from "react";
import {useTranslation} from "react-i18next";

type LinkWithCopyProps = {
    link: string;
    placeholder: string;
}

export const LinkWithCopy = ({link, placeholder}: LinkWithCopyProps) => {
    const {t} = useTranslation()
    const [isCopied, setIsCopied] = useState<boolean>(false)

    const handleCopy = () => {
        if (isCopied) {
            return;
        }
        copyToClipboard(link)
        setIsCopied(true)
        setTimeout(() => {
            setIsCopied(false)
        }, 2000)
    }

    return (
        <div className="link">
            <input
                type="text"
                readOnly
                name="link"
                id="link"
                placeholder={placeholder}
                onClick={handleCopy}
                value={isCopied ? t("Copied") : link}
            />
            <div className="badge" onClick={handleCopy}>
                {t('Copy')}
            </div>
        </div>
    );
};
