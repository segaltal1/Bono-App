import React, {useContext, useEffect} from 'react';
import {AppContext} from "../../../MainContext/AppContext";
import {finalize, toChecksumAddress} from "../../../Helpers/eth";
import {useNavigate} from "react-router-dom";

type CreateLinkButtonProps = {}
export const CreateLinkButton = () => {
    const navigate = useNavigate();

    const {
        amount, receiver, token, chain, account, currency,
        setEmbed,
        setLink,
        embed,
        link,

    } = useContext(AppContext);


    const isDisabled = !Number(amount) || !toChecksumAddress(token, true) || !toChecksumAddress(receiver, true)

    const handleClick = async () => {


        const {
            url,
            embed
        } = await finalize({account, chain, token, receiver, amount, currency})



        if (embed) {
            setEmbed(embed)
            setLink(url)
        }

    }

    useEffect(() => {
        if (embed && link) {
            navigate('/thank-you');
        }

    }, [embed, link])


    return (
        <button
            id="finalize"
            type="button"
            disabled={isDisabled}
            className="button truncate"
            onClick={handleClick}>
            Create link
        </button>
    )
}