import {useContext, useEffect, useState} from 'react';
import {AppContext} from "../../../MainContext/AppContext";
import {approve, checkAllowance, finalize, getAmountOut, pay, toChecksumAddress} from "../../../Helpers/eth";
import {useNavigate} from "react-router-dom";
import {useTranslation} from "react-i18next";
import {IMAGINARY_PEG} from "../../../Helpers/consts";

type CreateLinkButtonProps = {}
export const PayButton = () => {
    const navigate = useNavigate();
    const [amountOut, setAmountOut] = useState('');

    const {
        amount, receiver, token, chain, account, currency,
        embed,
        link,
        execToken,
        path,
        router,
        sig,
        provider
    } = useContext(AppContext);

    const {t} = useTranslation()
    const [status, setStatus] = useState<'pay' | 'approve' | 'paying' | 'approving' | ''>('')

    const isDisabled = !Number(amount) || !toChecksumAddress(token, true) || !toChecksumAddress(receiver, true)

    const handleClick = async () => {
        if (['paying', 'approving'].includes(status)) {
            return;
        }

        if (status === 'pay') {
            setStatus('paying');
            await pay({chain, provider, execToken, amount, currency, path, account, receiver, router, sig});
        } else {
            setStatus('approving');
            await approve({chain, provider, execToken, amount});
        }

        await checkStatus();
    }

    useEffect(() => {
        if (!execToken || execToken === IMAGINARY_PEG) {
            return setStatus('pay');
        }

        checkStatus();
    }, [execToken])

    useEffect(() => {
        const intervalId = askPrices()
        return () => {
            clearInterval(intervalId)
        }
    }, [])

    const updatePrice = async () => {
        setAmountOut((await getAmountOut(chain, provider, token, amount, currency)).prec(7).toString());
    };

    const askPrices = () => {
        updatePrice()
        return setInterval(updatePrice, 3000);
    }


    useEffect(() => {
        if (embed && link) {
            navigate('/thank-you');
        }

    }, [embed, link])

    const checkStatus = async () => {
        const amountOut = 0;
        const [path, router, _amount, _allowance] = await checkAllowance({
            execToken,
            chain,
            provider,
            amount,
            amountOut,
            account
        });

        if (_amount.lt(_allowance)) {
            return setStatus('pay');
        }

        return setStatus('approve');
    }


    return (
        <button
            hidden={!status}
            id="finalize"
            type="button"
            disabled={isDisabled}
            className="button truncate"
            onClick={handleClick}>
            {t(status as any)} {amountOut}
        </button>
    )
}