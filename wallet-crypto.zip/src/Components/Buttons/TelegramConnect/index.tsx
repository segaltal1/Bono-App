import React, {useState} from 'react';
import TelegramIcon from '../../../assets/images/telegram.svg';
import {useTranslation} from "react-i18next";

type TelegramButtonProps = {
    url: string;
}
export const TelegramButton = ({url}: TelegramButtonProps) => {
    const [isHide, setIsHide] = useState(false);
    const {t} = useTranslation()

    return (
        <div id="connect-telegram" hidden={isHide}>
            <a
                onClick={() => setIsHide(true)}
                href={url}
                target="_blank"
                rel="noreferrer">
                <img width="100%" src={TelegramIcon} alt="Connect Telegram"/> {t("Connect Telegram")}
            </a>
        </div>
    )
}