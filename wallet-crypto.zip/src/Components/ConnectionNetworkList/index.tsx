import {useContext} from "react";
import {AppContext} from "../../MainContext/AppContext";
import {ALLOWED_CHAINS, CHAIN_IDS_MAP, CHAINS} from "../../Helpers/consts";
import {_hex} from "../../Helpers/eth";

type NetworkItem = {
    name: string;
    imageUrl: string;
}

const networks: NetworkItem[] = [
    {
        name: 'BSC',
        imageUrl: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/smartchain/info/logo.png',
    },
    {
        name: 'ETH',
        imageUrl: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/info/logo.png',
    },
    {
        name: 'MATIC',
        imageUrl: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/polygon/info/logo.png',
    },
    {
        name: 'AVAX',
        imageUrl: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/avalanchec/info/logo.png',
    },
    {
        name: 'FTM',
        imageUrl: 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/fantom/info/logo.png',
    },
];

export const ConnectionNetworkList = () => {
    const {chain, account, setChain} = useContext(AppContext)

    async function changeNetwork(newChain) {
        console.log('Changing network to', newChain);

        if (!account) {
            document.querySelector('.connect').click()
            return;
        }

        if (newChain === chain) {
            return true;
        }

        if (!ALLOWED_CHAINS.includes(newChain)) {
            return alert('Comming soon...');
        }


        let curr_net = CHAINS[CHAIN_IDS_MAP[newChain]];

        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{chainId: _hex(curr_net.CHAIN_ID)}],
            });
        } catch (switchError) {
            /* console.log('!!', switchError); */

            /* This error code indicates that the chain has not been added to MetaMask. */
            if (switchError.code === 4902) {
                try {
                    newChain
                    await window.ethereum.request({
                        method: 'wallet_addEthereumChain',
                        params: [
                            {
                                chainId: _hex(curr_net.CHAIN_ID),
                                chainName: curr_net.CHAIN,
                                rpcUrls: [curr_net.RPC],
                                blockExplorerUrls: [curr_net.EXPLORER],
                                nativeCurrency: {
                                    name: curr_net.PEG,
                                    symbol: curr_net.PEG,
                                    decimals: curr_net.DECIMALS,
                                },
                            },
                        ],
                    });
                } catch (e) {
                }
            }
        }

        setChain(newChain);
    }

    return (
        <div id="connections">
            {networks.map((network) => (
                <div
                    onClick={async (event) => changeNetwork(network.name)}
                    key={network.name}
                    className={`connection ${chain !== network.name ? 'gray' : ''}`}
                    data-chain={network.name}
                    style={{cursor:'pointer'}}
                >
                    <div>
                        <img src={network.imageUrl} alt={network.name}/>
                    </div>
                </div>
            ))}
        </div>
    )
}

