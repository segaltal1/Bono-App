import {NavLink} from "react-router-dom";
import {useTranslation} from "react-i18next";

export const Footer = () => {
    const {t} = useTranslation()
    return (
        <div id="footer">
            <div className="links">
                <NavLink to="/about">{t('About')}</NavLink>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <NavLink to="/">{t('Home')}</NavLink>
            </div>
				<span id="powered-by">
					Powered by{' '}
                    <a href="/" target="_blank" rel="noreferrer">
						Token Flow
					</a>{' '}
                    💪
					<br />
				</span>
            &copy; All rights reserved, <span id="year">{new Date().getFullYear()}</span>.
        </div>
    )
}

