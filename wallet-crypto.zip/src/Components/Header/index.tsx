import React, {useContext} from 'react';
import Logo from '../../assets/images/logo.png'
import TelegramIcon from "../../assets/images/telegram.svg"
import {AppContext} from "../../MainContext/AppContext";
import {getAccount, onSessionConnected, web3Modal} from "../../Helpers/eth";
import {SignClient} from '@walletconnect/sign-client';
import {useTelegramAccount} from "../../Helpers/hooks";
import {TelegramButton} from "../Buttons/TelegramConnect";
import {LanguageSwitcher} from "../LanguageSwitcher";
import {Link} from "react-router-dom";
import {ConnectWalletButton} from "../Buttons/ConnectWalletButton";


type HeaderProps = {
    children: React.ReactNode;
};

export const Header = () => {
    const {
        session,
        account,
        signClient,

    } = useContext(AppContext);


    const isConnected = false;

    const {isFinish, accountUrl} = useTelegramAccount(account);

    async function handleDisconnect() {
        try {
            await signClient.disconnect({
                topic: session.topic,
                message: 'User disconnected',
                code: 6000,
            });
        } catch (e) {
            console.log(e);
        } finally {
            localStorage.clear();
            window.location.reload();
        }
    }


    return (
        <div id="logo" className="iframe header">
            <div className="d-flex align-items-center gap-1">
                <Link to="/" className="d-flex align-items-center gap-1">
                    <img src={Logo} alt="Token Flow logo"/>
                    ryptbit
                </Link>
                <LanguageSwitcher/>
            </div>

            <div className="d-flex align-items-center flex-wrap">
                {
                    /*account === null ?
                        <></>
                        :*/
                    account ?
                        <>
                            {accountUrl && isFinish && <TelegramButton url={accountUrl}/>}
                            <div id="disconnect" className="button truncate" onClick={handleDisconnect}>
                                {account}
                            </div>
                        </>

                        :
                        <ConnectWalletButton/>
                }

            </div>
        </div>
    );
};

