import React, {useContext, useState} from 'react';
import {AppContext} from "../../../MainContext/AppContext";
import Select from "react-select";
import {useTranslation} from "react-i18next";

type CurrencyInputProps = {
    disabled?: boolean;
}

export const CurrencyInput = ({disabled}: CurrencyInputProps) => {
    const {currency, setCurrency, clearLinks, amount, setAmount} = useContext(AppContext);
    // const [amount, setAmount] = useState<number | string>("")
    const {t} = useTranslation()

    const changeCurrency = (event) => {
        setCurrency(event.value);
        localStorage.setItem('currency', event.value);
        clearLinks()
    }

    const handleInputChange = (event) => {
        setAmount(event.target.value.replace(/[^0-9.]/g, '').replace(/([0-9]+(\.[0-9]{0,2})?).*/, '$1'))
    }


    const tokens = [
        {value: 'USD', label: 'USD ($)'},
        {value: 'CNY', label: 'CNY (¥)'},
        {value: 'EUR', label: 'EUR (€)'},
        {value: 'GBP', label: 'GBP (£)'},
        {value: 'ILS', label: 'ILS (₪)'},
        {value: 'INR', label: 'INR (₹)'},
        {value: 'RUB', label: 'RUB (₽)'},
        {value: 'SAR', label: 'SAR (﷼)'},
    ];

    const selectedOption = tokens.find(v => v.value === currency) || tokens[0]

    return (
        <div className="container">
            <Select
                id="currency"
                name="currency"
                className="select"
                value={selectedOption}
                onChange={changeCurrency}
                isDisabled={disabled}
                options={tokens}
            />
            <textarea
                id="amount"
                onInput={handleInputChange}
                onKeyUp={handleInputChange}
                placeholder={t('Enter amount')}
                value={amount || ''}
                disabled={disabled}
                readOnly={disabled}

            ></textarea>
        </div>
    )
}