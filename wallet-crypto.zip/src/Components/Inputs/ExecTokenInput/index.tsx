import React, {useContext, useState} from 'react';
import {AppContext} from "../../../MainContext/AppContext";
import Select from "react-select";
import {CHAIN_IDS_MAP, CHAINS} from "../../../Helpers/consts";
import {getTokensByChain, toChecksumAddress} from "../../../Helpers/eth";


export const ExecTokenInput = () => {

    const [otherToken, setOtherToken] = useState<string>('')
    const [isOtherOption, setIsOtherOption] = useState<boolean>(false)
    const {account, chain, execToken, setExecToken} = useContext(AppContext);

    if (!account || !chain) return null;

    const changeToken = (event) => {
        setIsOtherOption(event.value === '0x00')
        const _token = toChecksumAddress(event.value)
        setExecToken(_token);
    }

    const handleTokenChange = (event) => {
        try {
            const address = toChecksumAddress(event.target.value, true);
            if (address) {
                setExecToken(address);
            }
        } catch (e) {
            console.log(e);
        } finally {
            setOtherToken(event.target.value)
        }

    }


    return (
        <div className="container" id="receive-with">
            <div className="arrow top">⇣</div>
            <Select
                id="receive-token"
                name="receive-token"
                className="select"
                onChange={changeToken}
                value={{
                    label:
                        Object.keys(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP)[
                            Object.values(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP).indexOf(execToken)
                            ] || Object.keys(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP)[0],
                    value: execToken || Object.values(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP)[0],
                }}
                isRtl={false}
                options={getTokensByChain(chain) as any}
            />
            <textarea
                id="receive-token-hash"
                readOnly={!isOtherOption}
                disabled={!isOtherOption}
                placeholder="0x..."
                value={isOtherOption ? otherToken : (execToken || Object.values(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP)[0])}
                onChange={handleTokenChange}
            ></textarea>
        </div>
    )
}