import React, {useEffect, useState} from 'react';
import i18n from '../../i18n'
import Select from "react-select";
import {useTranslation} from "react-i18next";

const languages = [
    {
        value: 'en',
        label: 'EN',
        country: 'us'
    },
    {
        value: 'fr',
        label: 'FR',
        country: 'fr'
    },
    {
        value: 'es',
        label: 'ES',
        country: 'es'
    }
]

export const LanguageSwitcher: React.FC = () => {
    const [selectedLang, setSelectedLang] = useState(
        languages.find(lang => lang.value === (i18n.language || 'en') || 'en')
    )


    const handleLanguageChange = async (event: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedLang = event.value;
        await i18n.changeLanguage(selectedLang);
    };

    useEffect(() => {
        i18n.on('languageChanged', newLang => {
            setSelectedLang(languages.find(lang => lang.value === newLang))
        });
    }, [])

    const customStyles = {
        control: (provided, state) => ({
            ...provided,
            backgroundColor: 'transparent',
            borderColor: 'transparent',
            boxShadow: 'none',
            '&:hover': {
                borderColor: 'grey'
            },
            cursor: 'pointer'
        }),
        menu: (provided) => ({
            ...provided,
            backgroundColor: 'rgba(255, 255, 255, 0.9)', // Slightly transparent menu
        }),
        option: (provided, state) => ({
            ...provided,
            backgroundColor: state.isFocused ? 'rgba(0, 123, 255, 0.1)' : 'transparent',
            color: state.isFocused ? 'black' : 'black',
            '&:hover': {
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
            }
        }),
        singleValue: (provided) => ({
            ...provided,
            color: 'black'
        }),
    };

    return (
        <div>
            <Select
                isSearchable={false}
                id="language"
                name="language"
                className="select"
                value={selectedLang}
                onChange={handleLanguageChange}
                styles={customStyles}
                options={languages}
                formatOptionLabel={option => (
                    <div className="option-label d-flex align-items-center justify-center">
                        <img
                            src={`https://flagcdn.com/16x12/${option.country}.png`}
                            alt={`flag of ${option.label}`}
                            style={{width: '16px'}}
                        />
                        {/*{option.label}*/}
                    </div>
                )}
            />
        </div>
    );
};