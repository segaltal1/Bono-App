import React, {useContext, useEffect} from 'react';
import {Header} from "../Header";
import {Footer} from "../Footer";
import {createClient, onSessionConnected} from "../../Helpers/eth";
import {AppContext} from "../../MainContext/AppContext";
import {geoip} from "../../Helpers/utils";


type LayoutProps = {
    children: React.ReactNode;
};

export const Layout = ({children}: LayoutProps) => {
    const {
        setSignClient,
        signClient,
        session,
        currency,
        token,
        setChain,
        setProvider,
        setSession,
        setAccount,
        setCurrency

    } = useContext(AppContext);

    //when mount
    useEffect(() => {
        if (!currency) {
            geoip().then(setCurrency)
        }

    }, [])

    useEffect(() => {
        if (!signClient) {
            createClient().then(setSignClient)
        } else {
            if (session) {
                setSession(session);
                const {chain, provider, account} = onSessionConnected(session);
                setChain(chain);
                setProvider(provider);
                setAccount(account);
            }
        }
    }, [signClient]);

    //listen to token change
    useEffect(() => {
        localStorage.setItem('token', token)
    }, [token])


    return (
        <React.Fragment>
            <Header/>
            <div className="layout-wrapper">{children}</div>
            <Footer/>
        </React.Fragment>
    );
};

