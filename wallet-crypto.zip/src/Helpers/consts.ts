import { ethers } from 'ethers';

export const ALLOWED_CHAINS = ['BSC', 'ETH', 'MATIC', 'FTM', 'AVAX'];

export const API = 'https://api.tokenflow.link'; /* Notification server */
export const IMAGINARY_PEG = '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';
export const ZERO = '0x0000000000000000000000000000000000000000';
export const CONTRACTS = {};
export const CONSTANTS = {};
export const PROVIDER = {};
export const DECIMALS = {};
export const WEB3_HELPERS = {};

export const CHAINS = {
    1: {
        EXPLORER: 'https://etherscan.io',
        CHAIN_ID: 1,
        CHAIN: 'ETH',
        CHAIN_ASSETS: 'ethereum',
        PEG: 'ETH',
        DECIMALS: 18,
        WPEG: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2' /*  WBNB */,
        ROUTER: '0xE592427A0AEce92De3Edee1F18E0157C05861564',
        CHECKER: '0x894D95F83AE62Bf165979fB4B9DE0d9768D0753C',
        HELPER: '0x894D95F83AE62Bf165979fB4B9DE0d9768D0753C',
        RPC: 'https://free.rpcpool.com/',
        STABLE: ['0xdAC17F958D2ee523a2206206994597C13D831ec7'],
        BLUECHIPS: [],
        TOKENS_MAP: {
            ETH: IMAGINARY_PEG,
            WBNB: '0x418d75f65a02b3d53b2418fb8e1fe493759c7605',
            WMATIC: '0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0',
            WFTM: '0x4e15361fd6b4bb609fa63c81a2be19d873717870',
            WAVAX: '0x85f138bfee4ef8e540890cfb48f620571d67eda3',
            WETH: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
            XTZ: '0x2e59005c5c0f0a4D77CcA82653d48b46322EE5Cd',
            BTC: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
            DOGE: '0x3832d2F059E55934220881F831bE501D180671A7',
            USDT: '0xdac17f958d2ee523a2206206994597c13d831ec7',
            BUSD: '0x4Fabb145d64652a948d72533023f6E7A623C7C53',
            wXMR: '0x465e07d6028830124BE2E4aA551fBe12805dB0f5',
            Other: '0x00'
        },
    },
    56: {
        EXPLORER: 'https://bscscan.com',
        CHAIN_ID: 56,
        CHAIN: 'BSC',
        CHAIN_ASSETS: 'smartchain',
        PEG: 'BNB',
        DECIMALS: 18,
        WPEG: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c' /*  WBNB */,
        ROUTER: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
        FACTORY: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
        CHECKER: '0xE98EE2aa4Dc9C85B8fEbb78D781102a30e7E0EE3',
        HELPER: '0x5416dE11512Ac38709761d20e7Ac77644bc5b299',
        RPC: 'https://bsc-dataseed.binance.org/',
        BLUECHIPS: [
            '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
            '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
            '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82',
            '0x42b98A2f73a282D731b0B8F4ACfB6cAF3565496B',
            '0xC9882dEF23bc42D53895b8361D0b1EDC7570Bc6A',
            '0xeEeEEb57642040bE42185f49C52F7E9B38f8eeeE',
        ],
        STABLE: [
            '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
            '0x03ab98f5dc94996F8C33E15cD4468794d12d41f9',
            '0x55d398326f99059fF775485246999027B3197955',
            '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
            '0x14016E85a25aeb13065688cAFB43044C2ef86784',
            '0xb3c11196A4f3b1da7c23d9FB0A3dDE9c6340934F',
            '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3',
        ],
        TOKENS_MAP: {
            BNB: IMAGINARY_PEG,
            WBNB: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
            WMATIC: '0xCC42724C6683B7E57334c4E856f4c9965ED682bD',
            WFTM: '0xAD29AbB318791D579433D831ed122aFeAf29dcfe',
            WAVAX: '0x1CE0c2827e2eF14D5C4f29a091d735A204794041',
            WETH: '0x2170Ed0880ac9A755fd29B2688956BD959F933F8',
            XTZ: '0x16939ef78684453bfDFb47825F8a5F714f12623a',
            BTC: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c',
            DOGE: '0xbA2aE424d960c26247Dd6c32edC70B295c744C43',
            USDT: '0x55d398326f99059ff775485246999027b3197955',
            BUSD: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
            wXMR: '0xbC4081a8b192a50bD58AC6C595d766e59a56C37E',
            Other: '0x00'
        },
    },
    97: {
        /*  Testnet */ EXPLORER: 'https://testnet.bscscan.com',
        CHAIN_ID: 97,
        CHAIN: 'BSCT',
        CHAIN_ASSETS: 'smartchain',
        PEG: 'BNB',
        DECIMALS: 18,
        WPEG: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd' /*  WBNB */,
        ROUTER: '0x9Ac64Cc6e4415144C455BD8E4837Fea55603e5c3',
        CHECKER: '0x28E3CBd864Ea279470e289A27E397fe73b912117',
        HELPER: '0x3CA3f9ee5C434275176778A89f5F4378d8000ea8',
        RPC: 'https://data-seed-prebsc-1-s1.binance.org:8545/',
        STABLE: ['0x7ef95a0FEE0Dd31b22626fA2e10Ee6A223F8a684'],
        BLUECHIPS: ['0x8BaBbB98678facC7342735486C851ABD7A0d17Ca'],
        TOKENS_MAP: {
            BNB: IMAGINARY_PEG,
            WBNB: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
            WETH: '0x8BaBbB98678facC7342735486C851ABD7A0d17Ca',
            USDT: '0x7ef95a0FEE0Dd31b22626fA2e10Ee6A223F8a684',
            BUSD: '0x78867BbEeF44f2326bF8DDd1941a4439382EF2A7',
        },
    },
    137: {
        EXPLORER: 'https://polygonscan.com',
        CHAIN_ID: 137,
        CHAIN: 'MATIC',
        CHAIN_ASSETS: 'polygon',
        PEG: 'MATIC',
        DECIMALS: 18,
        WPEG: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270' /*  WMATIC */,
        ROUTER: '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff',
        CHECKER: '0xd0A9cd742eDC395D50F4162A2B40FFBa9c1384D8',
        HELPER: '0xd0A9cd742eDC395D50F4162A2B40FFBa9c1384D8',
        RPC: 'https://matic-mainnet.chainstacklabs.com',
        STABLE: [
            '0x2088C47Fc0c78356c622F79dBa4CbE1cCfA84A91',
            '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
            '0x2e1AD108fF1D8C782fcBbB89AAd783aC49586756',
            '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
            '0xdAb529f40E671A1D4bF91361c21bf9f0C9712ab7',
            '0x9719d867a500ef117cc201206b8ab51e794d3f82',
            '0x1a13F4Ca1d028320A707D99520AbFefca3998b7F',
            '0xC8A94a3d3D2dabC3C1CaffFFDcA6A7543c3e3e65',
            '0xC79358DE3868A7C751F52cFeECd650595AEE8B18',
            '0xF81b4Bec6Ca8f9fe7bE01CA734F55B2b6e03A7a0',
            '0x9aF3b7DC29D3C4B1A5731408B6A9656fA7aC3b72',
            '0xD07A7FAc2857901E4bEC0D89bBDAe764723AAB86',
            '0x60D55F02A771d515e077c9C2403a1ef324885CeC',
        ],
        BLUECHIPS: [],
        TOKENS_MAP: {
            MATIC: IMAGINARY_PEG,
            WBNB: '0xa649325aa7c5093d12d6f98eb4378deae68ce23f',
            WMATIC: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
            WFTM: '0xb85517b87bf64942adf3a0b9e4c71e4bc5caa4e5',
            WAVAX: '0x2c89bbc92bd86f8075d1decc58c7f4e0107f286b',
            WETH: '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619',
            BTC: '0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6',
            DOGE: '0xcE829A89d4A55a63418bcC43F00145adef0eDB8E',
            USDT: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f',
            BUSD: '0xdAb529f40E671A1D4bF91361c21bf9f0C9712ab7',
            Other: '0x00'
        },
    },
    250: {
        EXPLORER: 'https://ftmscan.com',
        CHAIN_ID: 250,
        CHAIN: 'FTM',
        CHAIN_ASSETS: 'fantom',
        PEG: 'FTM',
        DECIMALS: 18,
        WPEG: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83' /*  WFTM */,
        ROUTER: '0xF491e7B69E4244ad4002BC14e878a34207E38c29',
        CHECKER: '0x3710c29593cC230CB5516948Ec865510473156F1',
        HELPER: '0x3710c29593cC230CB5516948Ec865510473156F1',
        RPC: 'https://rpc.ftm.tools/',
        STABLE: [
            '0xAd84341756Bf337f5a0164515b1f6F993D194E1f',
            '0x04068DA6C83AFCFA0e13ba15A6696662335D5B75',
            '0x940F41F0ec9ba1A34CF001cc03347ac092F5F6B5',
            '0xe578C856933D8e1082740bf7661e379Aa2A30b26',
        ],
        BLUECHIPS: [],
        TOKENS_MAP: {
            FTM: IMAGINARY_PEG,
            WBNB: '0xd67de0e0a0fd7b15dc8348bb9be742f3c5850454',
            WMATIC: '0xCC42724C6683B7E57334c4E856f4c9965ED682bD',
            WFTM: '0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83',
            WAVAX: '0x511d35c52a3c244e7b8bd92c0c297755fbd89212',
            WETH: '0x74b23882a30290451a17c44f4f05243b6b58c76d',
            BTC: '0xe1146b9AC456fCbB60644c36Fd3F868A9072fc6E',
            DOGE: '0xEb0a2D1b1a33D95204af5d00f65FD9e349419878',
            USDT: '0x049d68029688eabf473097a2fc38ef61633a3c7a',
            Other: '0x00'
        },
    },
    1337: {
        EXPLORER: 'about:blank',
        CHAIN_ID: 1337,
        CHAIN: 'GANACH',
        CHAIN_ASSETS: 'ganache',
        PEG: 'ETH',
        DECIMALS: 18,
        WPEG: '0x97866Bd7627CC39F568d6aea36C3226A83D44bB3' /*  WETH */,
        ROUTER: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
        CHECKER: '0x141491eb10F5Fa9Dab704dcecAB692b77CBaCbe0',
        HELPER: '0x141491eb10F5Fa9Dab704dcecAB692b77CBaCbe0',
        RPC: 'http://10.0.0.4:7545/',
        STABLE: ['0x89F858ca9aF9Ce69B1D6FD4157CA015ca14B87f1'],
        BLUECHIPS: [],
        TOKENS_MAP: {
            WBNB: '0x97866Bd7627CC39F568d6aea36C3226A83D44bB3',
            WMATIC: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            WFTM: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            WAVAX: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            ETH: '0x89F858ca9aF9Ce69B1D6FD4157CA015ca14B87f1',
            WETH: '0x89F858ca9aF9Ce69B1D6FD4157CA015ca14B87f1',
            XTZ: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            BTC: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            DOGE: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            BUSD: '0x89F858ca9aF9Ce69B1D6FD4157CA015ca14B87f1',
            wXMR: '0xbE33Ff4B45825513aCC28A21BD885b08632Fc2d7',
            Other: '0x00'
        },
    },
    43114: {
        EXPLORER: 'https://cchain.explorer.avax.network',
        CHAIN_ID: 43114,
        CHAIN: 'AVAX',
        CHAIN_ASSETS: 'avalanchec',
        PEG: 'AVAX',
        DECIMALS: 18,
        WPEG: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7' /*  WAVAX */,
        ROUTER: '0x60aE616a2155Ee3d9A68541Ba4544862310933d4',
        CHECKER: '0x902599A6836C75B69c2ccf378FBFa7c4d0D956EB' /*  Trader Joe */,
        HELPER: '0x902599A6836C75B69c2ccf378FBFa7c4d0D956EB' /*  Trader Joe */,
        RPC: 'https://api.avax.network/ext/bc/C/rpc',
        STABLE: [
            '0xc7198437980c041c805A1EDcbA50c1Ce5db95118',
            '0xA7D7079b0FEaD91F3e65f86E8915Cb59c1a4C664',
            '0xde3A24028580884448a5397872046a019649b084',
            '0x46A51127C3ce23fb7AB1DE06226147F446e4a857',
            '0x532E6537FEA298397212F09A61e03311686f548e',
        ],
        BLUECHIPS: [],
        TOKENS_MAP: {
            AVAX: IMAGINARY_PEG,
            WBNB: '0x49D5c2BdFfac6CE2BFdB6640F4F80f226bc10bAB',
            WMATIC: '0xf2f13f0B7008ab2FA4A2418F4ccC3684E49D20Eb',
            WAVAX: '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7',
            BTC: '0x50b7545627a5162F82A992c33b87aDc75187B218',
            USDT: '0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7',
            BUSD: '0x19860CCB0A68fd4213aB9D8266F7bBf05A8dDe98',
            Other: '0x00'
        },
    },
};

export const CHAIN_IDS_MAP = {
    ETH: 1,
    BSC: 56,
    BSCT: 97,
    MATIC: 137,
    FTM: 250,
    GANACHE: 1337,
    AVAX: 43114,
};

export const IDS_CHAIN_MAP = {
    1: 'ETH',
    56: 'BSC',
    97: 'BSCT',
    137: 'MATIC',
    250: 'FTM',
    1337: 'GANACHE',
    43114: 'AVAX',
};

export const ABI = [
    {
        inputs: [
            {
                internalType: 'address',
                name: 'owner',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
        ],
        name: 'allowance',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'spender',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'approve',
        outputs: [
            {
                internalType: 'bool',
                name: '',
                type: 'bool',
            },
        ],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'account',
                type: 'address',
            },
        ],
        name: 'balanceOf',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'factory',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        name: 'getPair',
        outputs: [
            {
                internalType: 'address',
                name: '',
                type: 'address',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'decimals',
        outputs: [
            {
                internalType: 'uint8',
                name: '',
                type: 'uint8',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'uint256',
                name: 'amountIn',
                type: 'uint256',
            },
            {
                internalType: 'address[]',
                name: 'path',
                type: 'address[]',
            },
        ],
        name: 'getAmountsOut',
        outputs: [
            {
                internalType: 'uint256[]',
                name: 'amounts',
                type: 'uint256[]',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'string',
                name: '',
                type: 'string',
            },
        ],
        name: 'PRICES',
        outputs: [
            {
                internalType: 'uint256',
                name: '',
                type: 'uint256',
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'receiver',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
            {
                internalType: 'string',
                name: 'currency',
                type: 'string',
            },
            {
                internalType: 'address[]',
                name: 'token_path',
                type: 'address[]',
            },
        ],
        name: 'getMessageHash',
        outputs: [
            {
                internalType: 'bytes32',
                name: '',
                type: 'bytes32',
            },
        ],
        stateMutability: 'pure',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'receiver',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: '_price',
                type: 'uint256',
            },
            {
                internalType: 'string',
                name: 'currency',
                type: 'string',
            },
            {
                internalType: 'address',
                name: 'token_router',
                type: 'address',
            },
            {
                internalType: 'address[]',
                name: 'token',
                type: 'address[]',
            },
            {
                internalType: 'bytes',
                name: 'signature',
                type: 'bytes',
            },
        ],
        name: 'pay',
        outputs: [],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            {
                internalType: 'address',
                name: 'router',
                type: 'address',
            },
            {
                internalType: 'address[]',
                name: 'path',
                type: 'address[]',
            },
            {
                internalType: 'address',
                name: 'to',
                type: 'address',
            },
            {
                internalType: 'address',
                name: 'receiver',
                type: 'address',
            },
            {
                internalType: 'uint256',
                name: '_price',
                type: 'uint256',
            },
            {
                internalType: 'string',
                name: 'currency',
                type: 'string',
            },
            {
                internalType: 'address',
                name: 'token_router',
                type: 'address',
            },
            {
                internalType: 'address[]',
                name: 'token_path',
                type: 'address[]',
            },
            {
                internalType: 'bytes',
                name: 'signature',
                type: 'bytes',
            },
            {
                internalType: 'uint8',
                name: 'sell_fee',
                type: 'uint8',
            },
        ],
        name: 'pay',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'symbol',
        outputs: [
            {
                name: '',
                type: 'string',
            },
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
];

export const iface = new ethers.Interface(ABI);
