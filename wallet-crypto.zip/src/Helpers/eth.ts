import {Web3Modal} from "@web3modal/standalone";
import SignClient from "@walletconnect/sign-client";
import {
    ABI,
    CHAIN_IDS_MAP,
    CHAINS,
    CONSTANTS,
    CONTRACTS, DECIMALS,
    IDS_CHAIN_MAP, iface,
    IMAGINARY_PEG,
    WEB3_HELPERS
} from "./consts";
import {ethers} from "ethers";
import {Big} from 'big.js'

const projectId = import.meta.env.VITE_APP_PROJECT_ID;

export const web3Modal = new Web3Modal({
    projectId: projectId,
    standaloneChains: ['eip155:56'],
});

export const createClient = async () => {
    try {
        return SignClient.init({
            projectId: projectId,
        });
    } catch (e) {
        console.log(e);
    }
}

export const getTokensByChain = (chain: string) => {
    return Object.keys(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP).map((key) => ({
        value: CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP[key],
        label: key,
    }));
}

export const getDefaultRouter = chain => CHAINS[CHAIN_IDS_MAP[chain]].ROUTER;

export const onSessionConnected = (session) => {
    if (!(window as any).ethereum) {
        throw new Error('cannot access to ethereum')
    }
    try {
        return {
            chain: IDS_CHAIN_MAP[session?.namespaces?.eip155?.accounts[0]?.split(':')[1]],
            account: session?.namespaces?.eip155?.accounts[0]?.split(':')[2],
            provider: new ethers.BrowserProvider((window as any).ethereum)
        }
    } catch (e) {
        console.error(e);
    }

}

export const toChecksumAddress = (address, check = false) => {
    if (!address) {
        return '';
    }

    if (address.length < 42) {
        return !check && address;
    }

    if (!/^(0x)?[0-9a-fA-F]{1,40}$/i.test(address)) {
        // throw new Error('Given address "' + address + '" is not a valid Ethereum address.');
        return '';
    }

    address = address.toLowerCase().replace(/^0x/i, '');
    let addressHash = ethers.keccak256(ethers.toUtf8Bytes(address)).replace(/^0x/i, '');
    let checksumAddress = '0x';

    for (let i = 0; i < address.length; i++) {
        /* If ith character is 8 to f then make it uppercase */
        if (parseInt(addressHash[i], 16) > 7) {
            checksumAddress += address[i].toUpperCase();
        } else {
            checksumAddress += address[i];
        }
    }

    return checksumAddress;
}

function getProvider(chain, provider = undefined) {
    if (provider) {
        return provider;
    }

    if (typeof WEB3_HELPERS[chain] === 'undefined') {
        WEB3_HELPERS[chain] = new ethers.JsonRpcProvider(CHAINS[CHAIN_IDS_MAP[chain]].RPC);
    }

    return WEB3_HELPERS[chain];
}

function contract(provider, token, abi = ABI, chain = 'BSC') {
    const id = `${chain}-${token}`;

    if (typeof CONTRACTS[id] === 'undefined') {
        CONTRACTS[id] = new ethers.Contract(token, abi, getProvider(chain, provider));
    }

    return CONTRACTS[id];
}

async function getConstant(chain, provider, address, func, ...args) {
    let key = `${func}-${args.join('-')}`;

    if (!CONSTANTS[key]) {
        CONSTANTS[key] = await contract(provider, address, ABI, chain)
            [func](...args)
            .catch((_) => 0);
    }

    return CONSTANTS[key];
}

export const getPath = async (chain, provider, from_token, to_token) => {
    let path = [];


    const BLUCHIPS_AND_STABLE = [...CHAINS[CHAIN_IDS_MAP[chain]].BLUECHIPS, ...CHAINS[CHAIN_IDS_MAP[chain]].STABLE];

    if (from_token === to_token) {
        path = [to_token];
    } else if ([CHAINS[CHAIN_IDS_MAP[chain]].WPEG, IMAGINARY_PEG].includes(from_token)) {
        path = [CHAINS[CHAIN_IDS_MAP[chain]].WPEG, to_token];
    } else if ([CHAINS[CHAIN_IDS_MAP[chain]].WPEG, IMAGINARY_PEG].includes(to_token)) {
        path = [from_token, CHAINS[CHAIN_IDS_MAP[chain]].WPEG];
    } else {
        if (
            ethers.ZeroAddress !==
            (await getConstant(chain, provider,
                CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                'getPair',
                CHAINS[CHAIN_IDS_MAP[chain]].WPEG,
                to_token,
            ))
        ) {
            path = [from_token, CHAINS[CHAIN_IDS_MAP[chain]].WPEG, to_token];
        } else {
            for (let i = BLUCHIPS_AND_STABLE.length - 1; i >= 0; --i) {
                if (BLUCHIPS_AND_STABLE[i] === to_token) {
                    if (ethers.ZeroAddress !== (await getConstant(chain, CHAINS[CHAIN_IDS_MAP[chain]].FACTORY, 'getPair', from_token, to_token))) {
                        path = [from_token, to_token];
                    }
                } else if (
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        from_token,
                        BLUCHIPS_AND_STABLE[i],
                    )) &&
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider, CHAINS[CHAIN_IDS_MAP[chain]].FACTORY, 'getPair', to_token, BLUCHIPS_AND_STABLE[i]))
                ) {
                    path = [from_token, BLUCHIPS_AND_STABLE[i], to_token];
                } else if (
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        from_token,
                        CHAINS[CHAIN_IDS_MAP[chain]].WPEG,
                    )) &&
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        CHAINS[CHAIN_IDS_MAP[chain]].WPEG,
                        BLUCHIPS_AND_STABLE[i],
                    )) &&
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider, CHAINS[CHAIN_IDS_MAP[chain]].FACTORY, 'getPair', to_token, BLUCHIPS_AND_STABLE[i]))
                ) {
                    path = [from_token, CHAINS[CHAIN_IDS_MAP[chain]].WPEG, BLUCHIPS_AND_STABLE[i], to_token];
                } else if (
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        from_token,
                        BLUCHIPS_AND_STABLE[i],
                    )) &&
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        CHAINS[CHAIN_IDS_MAP[chain]].WPEG,
                        BLUCHIPS_AND_STABLE[i],
                    )) &&
                    ethers.ZeroAddress !==
                    (await getConstant(chain, provider,
                        CHAINS[CHAIN_IDS_MAP[chain]].FACTORY,
                        'getPair',
                        to_token,
                        CHAINS[CHAIN_IDS_MAP[chain]].WPEG,
                    ))
                ) {
                    path = [from_token, BLUCHIPS_AND_STABLE[i], CHAINS[CHAIN_IDS_MAP[chain]].WPEG, to_token];
                }
            }
        }
    }

    return {
        router: CHAINS[CHAIN_IDS_MAP[chain]].ROUTER,
        path
    };
}

export const _hex = (num) => {
    try {
        return `0x${BigInt(num).toString(16)}`;
    } catch (e) {
        /* Old browser */
        return `0x${Number(num).toString(16)}`;
    }
};

export const finalize = async ({account, chain, provider, token, receiver, amount, currency}, send: boolean = false) => {

    try {
        const {path, router} = await getPath(chain, provider, CHAINS[CHAIN_IDS_MAP[chain]].STABLE[0], token);
        const hash = await contract(CHAINS[CHAIN_IDS_MAP[chain]].HELPER, ABI, chain)
            .getMessageHash(account, receiver, _hex(Math.floor(amount * 100)), currency, path)
            .catch(() => false);

        if (!path.length) {
            return alert('No path found for this token');
        }

        if (!hash) {
            return console.warn('No hash');
        }

        return (window as any).ethereum
            .request({
                method: 'personal_sign',
                params: [hash, account],
            })
            .then((signature) => {
                const url = `${document.location.origin}/exec?to=${receiver}&amount=${amount}&currency=${currency}&token=${path}&sig=${signature}&router=${router}&send=${send}`;
                const embed = `<iframe src="${url}" title="Pay With Crypto" width="300" height="470" allowtransparency="1" style="border:0"></iframe>`;

                return {
                    url,
                    embed
                }
            })
            .catch(console.warn);
    } catch (e) {
        console.log('User rejected signature :(', e);
    }

}

export const getDecimals = async (chain, provider, token) => {
    if (!DECIMALS[chain]) {
        DECIMALS[chain] = {};
    }

    if (!DECIMALS[chain][token]) {
        DECIMALS[chain][token] = Number(
            await contract(provider, token.replace(IMAGINARY_PEG, CHAINS[CHAIN_IDS_MAP[chain]].WPEG)).decimals(),
        );
    }

    return DECIMALS[chain][token];
};

export const getPrice = async (chain, provider, path, default_val: number | undefined = undefined) => {
    try {
        return new Big(
            (
                await contract(provider, CHAINS[CHAIN_IDS_MAP[chain]].ROUTER).getAmountsOut(
                    _hex(10 ** (await getDecimals(chain, provider, path[0]))),
                    path,
                )
            )[path.length - 1],
        ).div(10 ** (await getDecimals(chain, provider, path[path.length - 1])));
    } catch (e) {
        return new Big(default_val || 0);
    }
}

export const getAmountOut = async (chain, provider, token, amount, currency) => {
    const forexPrice = (await contract(provider, CHAINS[CHAIN_IDS_MAP[chain]].HELPER).PRICES(currency)) || 1;
    const stablePrice = new Big(amount || 0)
        .mul(1e18)
        .mul(await getPrice(chain, provider, [CHAINS[CHAIN_IDS_MAP[chain]].STABLE[0], CHAINS[CHAIN_IDS_MAP[chain]].WPEG]))
        .div(forexPrice);

    if (!token || CHAINS[CHAIN_IDS_MAP[chain]].WPEG === token || IMAGINARY_PEG === token) {
        return stablePrice;
    }
    return (await getPrice(chain, provider, [CHAINS[CHAIN_IDS_MAP[chain]].WPEG, token])).mul(stablePrice);
}

export const checkAllowance = async ({execToken, chain, provider, amount, amountOut, account}) => {
    let _amount;
    const {path, router} = await getPath(chain, provider, execToken, CHAINS[CHAIN_IDS_MAP[chain]].STABLE[0]);

    if (!path.length) {
        return [[], ethers.ZeroAddress, 0, 0];
    }

    if ((execToken) === CHAINS[CHAIN_IDS_MAP[chain]].STABLE[0]) {
        _amount = new Big(amount);
    } else {
        _amount = new Big(amountOut).mul(
            (Object.values(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP).includes(execToken) && 1.01) || 1.42,
        );
    }

    console.log('??? amount::', _amount.toString());

    _amount = _amount.mul(10 ** (await getDecimals(chain, provider, execToken))).round();

    if (execToken === IMAGINARY_PEG) {
        return [path, router, _amount, -1];
    }

    if (execToken && account) {
        return [
            path,
            router,
            _amount,
            new Big(
                await contract(provider, execToken)
                    .allowance(account, CHAINS[CHAIN_IDS_MAP[chain]].HELPER)
                    .catch((_) => 0),
            ),
        ];
    }

    return [path, router, _amount, 0];
}

export const getAmount = async (chain, provider, path, amount, currency) => {
    return new Big(
        (
            await contract(provider, CHAINS[CHAIN_IDS_MAP[chain]].ROUTER).getAmountsOut(
                _hex(10 ** (await getDecimals(chain, provider, CHAINS[CHAIN_IDS_MAP[chain]].STABLE[0]))),
                [...path].reverse(),
            )
        )[1],
    )
        .mul(amount)
        .mul(100)
        .mul(1e18)
        .div(new Big(100).mul(await contract(provider, CHAINS[CHAIN_IDS_MAP[chain]].HELPER).PRICES(currency)))
        .mul(1.05)
        .round();
};

export const approve = async ({chain, provider, execToken, amount}) => {
    try {
        return send(execToken, provider, 'approve', CHAINS[CHAIN_IDS_MAP[chain]].HELPER, _hex(amount));
    } catch (e) {
        console.error('!! Approve error:', e)
    }
};

export const pay = async ({chain, provider, execToken, amount, currency, path, account, receiver, router, sig}) => {
    if (execToken === IMAGINARY_PEG) {
        return sendValue(
            chain,
            provider,
            CHAINS[CHAIN_IDS_MAP[chain]].HELPER,
            account,
            'pay(address,address,uint256,string,address,address[],bytes)',
            await getAmount(chain, provider, path, amount, currency),
            account,
            receiver,
            _hex(Math.floor(amount * 100)),
            currency,
            router,
            path.split(','),
            sig,
        )
            .catch(console.error);
    }

    console.log('??? path:', path);

    return send(
        chain,
        provider,
        CHAINS[CHAIN_IDS_MAP[chain]].HELPER,
        account,
        'pay(address,address[],address,address,uint256,string,address,address[],bytes,uint8)',
        path,
        account,
        receiver,
        _hex(Math.floor(amount * 100)),
        currency,
        router,
        path.split(','),
        sig,
        Object.values(CHAINS[CHAIN_IDS_MAP[chain]].TOKENS_MAP).includes(execToken) ? 1 : 25,
    )
        .catch(console.error); /* TODO: get sell fee */
}

async function send(chain, provider, token, account, func, ...args) {
    return sendValue(chain, provider, token, account, func, 0, ...args);
}

const sendValue = (chain, provider, token, account, func, value, ...args) => {
    return new Promise(async (resolve, reject) => {
        const [gasPrice, chainId, nonce] = await Promise.all([
            (async () => {
                return (await provider.getFeeData()).gasPrice;
            })(),
            (async () => {
                return (await provider.getNetwork()).chainId;
            })(),
            provider.getTransactionCount(account),
        ]);

        let tx = {
            from: account,
            to: token,
            maxFeePerGas: gasPrice,
            nonce,
            data: iface.encodeFunctionData(func, args),
            chainId,
            value: '',
            gasLimit: 0n
        };

        if (value) {
            tx.value = _hex(value);
        }

        try {
            tx.gasLimit = await provider.estimateGas(tx);
        } catch (e) {
            return reject(e);
        }

        try {
            /*
                TODO: Check https://www.npmjs.com/package/@ethersproject/hardware-wallets
                            https://docs.ethers.io/v5/api/other/hardware/#hw-ledger
            */

            const transaction = await (window as any).ethereum.request({
                method: 'eth_sendTransaction',
                params: [tx],
            });

            console.log('??? transaction:', transaction);

            const receipt = await provider.waitForTransaction(transaction);

            if (receipt.status) {
                return resolve(transaction.hash);
            }

            return reject(transaction.hash);
        } catch (err) {
            console.error(err);
            return reject(err);
        }
    });
};
