import {useEffect, useState} from "react";
import {API} from "./consts";

export const useTelegramAccount = (account) => {
    const [accountUrl, setAccountUrl] = useState<string>('');
    const [isFinish, setIsFinish] = useState(false)

    useEffect(() => {
        const checkAccount = async () => {
            try {
                let response = await fetch(`${API}/${account}`);
                let res = await response.json();

                if (!res) {
                    setAccountUrl(`https://t.me/paywithcrypto_bot?start=${account}`);
                } else {
                    setAccountUrl('');
                }
            } catch (e) {
                setAccountUrl('');
                console.error(e);
            } finally {
                setIsFinish(true)
            }
        };


        if (account) {

            checkAccount();
        }
    }, [account]);

    return {
        accountUrl,
        isFinish
    };
};