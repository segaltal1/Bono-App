import {f} from "vite/dist/node/types.d-aGj9QkWt";

export const copyToClipboard = (value) => {
    console.log('Copying', value);
    if (!value.startsWith('http') && !value.startsWith('<iframe')) {
        return;
    }


    if (typeof navigator.clipboard === 'undefined') {
        let textArea = document.createElement('textarea');
        textArea.value = value;
        textArea.style.position = 'fixed'; /* avoid scrolling to bottom */
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            if (!document.execCommand('copy')) {
                console.log('Was not possible to copy te text :(');
            }
        } catch (err) {
            console.log('Was not possible to copy te text: ', err);
        }

        document.body.removeChild(textArea);
    } else {
        navigator.clipboard.writeText(value);
    }


}

export const geoip = async () => {
    const CURRENCY_MAP = {
        ZH: 'CNY',
        ES: 'EUR',
        DE: 'EUR',
        FR: 'EUR',
        UK: 'GBP',
        IL: 'ILS',
        IN: 'INR',
        RU: 'RUB',
        SA: 'SAR',
        US: 'USD',
    };

    const res = await fetch('https://get.geojs.io/v1/ip/country.json').catch(e => {
        console.error(e);
        return {json: async () => ({country: 'USD'})}
    })

    const currency = CURRENCY_MAP[(await res.json())?.country] || 'USD';
    localStorage.setItem('currency', currency);

    return currency;
}
