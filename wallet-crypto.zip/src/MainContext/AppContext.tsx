import React, {createContext, useContext, useState, ReactNode} from 'react';
import {IMAGINARY_PEG} from "../Helpers/consts";

interface AppContextType {
    signClient: any;
    session: any;
    account: string;
    setSignClient: (client: any) => void;
    setSession: (session: any) => void;
    setAccount: (account: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const SignClientProvider: React.FC<{ children: ReactNode }> = ({children}) => {
    const [signClient, setSignClient] = useState<any>(null);
    const [session, setSession] = useState<any>(JSON.parse(localStorage.getItem('session') || 'null'));
    const [account, setAccount] = useState<string | null>(null);
    const [chain, setChain] = useState<"">("");
    const [amount, setAmount] = useState<number | null>(null);
    const [provider, setProvider] = useState<"">("");
    const [currency, setCurrency] = useState<string>(localStorage.getItem('currency'));
    const [token, setToken] = useState<string>(localStorage.getItem('token') || IMAGINARY_PEG);
    const [execToken, setExecToken] = useState<string>("");
    const [receiver, setReceiver] = useState<string>("");
    const [embed, setEmbed] = useState<string>("");
    const [link, setLink] = useState<string>("");
    const [sig, setSig] = useState<string>("");
    const [path, setPath] = useState<string>("");
    const [router, setRouter] = useState<string>("");

    const clearLinks = () => {
        setEmbed('')
        setLink('')
    }

    const contextObject = {
        signClient,
        session,
        account,
        chain,
        provider,
        currency,
        token,
        embed,
        link,
        amount,
        receiver,
        router,
        execToken,
        setExecToken,
        setRouter,
        setReceiver,
        setSignClient,
        setAmount,
        setSession,
        setAccount,
        setChain,
        setProvider,
        setCurrency,
        setToken,
        setLink,
        setEmbed,
        clearLinks,
        sig, setSig,
        path, setPath


    }
    //only for access to global state
    window.globalState = contextObject


    return (
        <AppContext.Provider value={contextObject}>
            {children}
        </AppContext.Provider>
    );
};

export {SignClientProvider, AppContext};
