import React from 'react';
import {useTranslation} from "react-i18next";

export const AboutPage = () => {
    const {t} = useTranslation()


    return (
        <>
            <h1>{t('About Page')}</h1>

            <div className="about-content">

                <p>Welcome to TokenFlow, your trusted partner in navigating the dynamic world of digital currencies. Our
                    innovative platform seamlessly integrates the advantages of cryptocurrency with the reliability of
                    forex
                    prices, offering a unique and secure way to transfer tokens.</p>

                <h2>Our Mission</h2>
                <p>At TokenFlow, we aim to revolutionize the way you manage and transfer digital assets. By combining
                    the
                    precision of forex price indexing with the decentralized nature of cryptocurrencies, we provide a
                    platform that ensures fair and transparent token transfers. Our mission is to empower users with a
                    secure, non-custodial wallet that puts you in complete control of your assets.</p>

                <h2>Features</h2>
                <p><b>Secure and Non-Custodial</b>: TokenFlow is fully non-custodial, meaning you have exclusive control
                    over your private keys and assets. We prioritize your security with advanced encryption and security
                    protocols.</p>
                <p><b>Forex-Indexed Transfers</b>: Experience the unique advantage of token transfers based on real-time
                    forex prices. This innovative feature ensures that your transactions are fair and transparent.</p>
                <p><b>User-Friendly Interface</b>: Manage your digital assets effortlessly with our clean, intuitive
                    interface designed for both beginners and experienced users.</p>
                <p><b>Multi-Currency Support</b>: TokenFlow supports a wide range of cryptocurrencies, allowing you to
                    manage all your digital assets in one convenient place.</p>
                <p><b>Instant Transactions</b>: Benefit from fast and efficient transactions. Send and receive tokens
                    quickly and securely.</p>
                <p><b>Real-Time Tracking</b>: Keep a close eye on your portfolio with real-time tracking and market
                    trends,
                    all accessible within the app.</p>
                <p><b>Reliable Customer Support</b>: Our dedicated support team is always ready to assist you. Whether
                    you
                    have a question or need help with a transaction, we are here for you.</p>

                <h2>Why Choose TokenFlow?</h2>
                <p><b>Security</b>: As a non-custodial wallet, TokenFlow ensures that only you have access to your
                    private
                    keys, providing the highest level of security for your digital assets.</p>
                <p><b>Transparency</b>: Our unique forex-indexed transfer system guarantees transparent and fair
                    transactions.</p>
                <p><b>Innovation</b>: TokenFlow combines the best of both worlds, merging the stability of forex pricing
                    with the flexibility of cryptocurrencies.</p>

                <p>Join us at TokenFlow and experience the future of digital currency management. Take control of your
                    assets with confidence and convenience.</p>
            </div>

        </>
    );
};

