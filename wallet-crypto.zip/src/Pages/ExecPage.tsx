import React, {useContext, useEffect} from "react";
import {useNavigate, useSearchParams} from "react-router-dom";
import {AppContext} from "../MainContext/AppContext";
import {CurrencyInput} from "../Components/Inputs/CurrencyInput";
import {useTranslation} from "react-i18next";
import {ExecTokenInput} from "../Components/Inputs/ExecTokenInput";
import {ConnectWalletButton} from "../Components/Buttons/ConnectWalletButton";
import {PayButton} from "../Components/Buttons/PayButton";
import {ConnectionNetworkList} from "../Components/ConnectionNetworkList";

export const ExecPage = () => {
    const {t} = useTranslation()
    const {
        setReceiver, setCurrency, setAmount, setToken, setSig, setPath, setRouter,
        receiver,
        account,
    } = useContext(AppContext)
    let [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate()

    useEffect(() => {
        if (!['to', 'currency', 'sig', 'token', 'amount', 'router'].every((v) => searchParams.has(v))) {
            navigate('/')
            return;
        }

        setReceiver(searchParams.get('to'))
        setCurrency(searchParams.get('currency'))
        setAmount(searchParams.get('amount'))
        setPath(searchParams.get('token'))
        setToken(searchParams.get('token').split(',')[0])
        setSig(searchParams.get('sig'))
        setRouter(searchParams.get('router'))
    }, [])


    return (
        <section>
            <h1>{t('Exec Page')}</h1>
            <div id="form">
                <h2>
                    {t('Send To')} {receiver}
                </h2>
                <CurrencyInput disabled={true}/>
                {account ?
                    <>
                        <ExecTokenInput/>
                        <PayButton/>
                    </>
                    :
                    <ConnectWalletButton/>
                }


            </div>
            <ConnectionNetworkList/>
        </section>
    );
};

