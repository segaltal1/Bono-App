import React from 'react';
import {Link} from "react-router-dom";
import {useTranslation} from "react-i18next";
import SendIcon from '../assets/images/send.svg'
import ReceiveIcon from '../assets/images/receive.svg'

export const HomePage = () => {
    const {t} = useTranslation()
    return (
        <section className="home-page d-flex gap-3">
            <Link to={'/receive'}>
                <div className="card">
                    <img style={{width: '2rem', margin: '0 0.5rem  0 0'}} src={ReceiveIcon} alt=""/>
                    {t('Receive')}
                </div>
            </Link>
            <Link to={'/send'}>
                <div className="card">
                    <img style={{margin: '0 0.5rem  0 0'}} src={SendIcon} alt=""/>
                    {t('Send')}
                </div>
            </Link>
        </section>

    )
};

