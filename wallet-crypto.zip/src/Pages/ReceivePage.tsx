import {useContext, useEffect} from 'react';
import {useTranslation} from "react-i18next";
import {AppContext} from "../MainContext/AppContext";
import {CurrencyInput} from "../Components/Inputs/CurrencyInput";
import {TokenInput} from "../Components/Inputs/TokenInput";
import {CreateLinkButton} from "../Components/Buttons/CreateLinkButton";
import {ConnectWalletButton} from "../Components/Buttons/ConnectWalletButton";
import {ConnectionNetworkList} from "../Components/ConnectionNetworkList";

export const ReceivePage = () => {
    const {t} = useTranslation()
    const {account, receiver, setReceiver} = useContext(AppContext);

    useEffect(() => {
        setReceiver(account)
    }, [account])


    return (
        <>
            <h1>{t('Receive tokens according to Forex prices')}</h1>
            <div id="form">

                <h2 id="title" className="truncate">
                    {t('Receive')}
                </h2>

                <CurrencyInput/>
                <TokenInput/>
                {account ?
                    <>
                        <div className="container" id="receiver-container">
                            <div className="arrow top">⇣</div>
                            <textarea
                                id="receiver"
                                placeholder="0x..."
                                value={receiver || ''}
                                onChange={e => setReceiver(e.target.value)}
                            ></textarea>
                        </div>
                        <CreateLinkButton/>
                    </>
                    :
                    <ConnectWalletButton/>
                }

            </div>

            <ConnectionNetworkList/>
        </>
    );
};

