import React, {useContext, useEffect, useState} from 'react';
import {AppContext} from "../MainContext/AppContext";
import Select from 'react-select';
import {CHAIN_IDS_MAP, CHAINS} from "../Helpers/consts";
import {ConnectionNetworkList} from "../Components/ConnectionNetworkList";
import {LinksSection} from "../Components/LinksSection";
import {CurrencyInput} from "../Components/Inputs/CurrencyInput";
import {TokenInput} from "../Components/Inputs/TokenInput";
import {CreateLinkButton} from "../Components/Buttons/CreateLinkButton";
import {useTranslation} from "react-i18next";
import {ConnectWalletButton} from "../Components/Buttons/ConnectWalletButton";

export const SendPage = () => {
    const {t} = useTranslation()
    const {account, receiver, setReceiver} = useContext(AppContext);

    useEffect(() => {
        setReceiver(account)
    }, [account])


    return (
        <>
            <h1>{t('Send tokens according to Forex prices')}</h1>
            <div id="form">

                <h2 id="title" className="truncate">
                    {t('Send to')} {receiver}
                </h2>

                <CurrencyInput/>
                <TokenInput/>
                {account ?
                    <>
                        <div className="container" id="receiver-container">
                            <div className="arrow top">⇣</div>
                            <textarea
                                id="receiver"
                                placeholder="0x..."
                                value={receiver || ''}
                                onChange={e => setReceiver(e.target.value)}
                            ></textarea>
                        </div>
                        <CreateLinkButton/>
                    </>
                    :
                    <ConnectWalletButton/>
                }

            </div>

            <ConnectionNetworkList/>
        </>
    );
};

