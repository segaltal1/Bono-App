import {useTranslation} from "react-i18next";
import React, {useContext, useEffect} from "react";
import {LinksSection} from "../Components/LinksSection";
import {AppContext} from "../MainContext/AppContext";
import {useNavigate} from 'react-router-dom'

export const ThankYouPage = () => {
    const {t} = useTranslation()
    const {link, embed} = useContext(AppContext)

    const navigate = useNavigate();

    useEffect(() => {
        console.log({
            embed,
            link
        })
        if (!link || !embed) {
            navigate('/')
        }
    }, [])


    return (
        <div>
            <h1>{t('Thank you page')}</h1>
            <LinksSection/>
        </div>
    );
};

