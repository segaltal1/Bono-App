import {Navigate} from 'react-router-dom';

import {HomePage} from "../Pages/HomePage";
import {ReceivePage} from "../Pages/ReceivePage";
import {SendPage} from "../Pages/SendPage";
import {ExecPage} from "../Pages/ExecPage";
import {ThankYouPage} from "../Pages/ThankYouPage";
import {AboutPage} from "../Pages/AboutPage";


type RouteType = {
    path: string;
    component: JSX.Element;
    exact?: boolean;
};


export const routes: RouteType[] = [
    {path: '/', component: <HomePage/>},
    {path: '/receive', component: <ReceivePage/>},
    {path: '/send', component: <SendPage/>},
    {path: '/exec', component: <ExecPage/>},
    {path: '/thank-you', component: <ThankYouPage/>},
    {path: '/about', component: <AboutPage/>},

    // this route should be at the end of all other routes
    // eslint-disable-next-line react/display-name
    {
        path: '/',
        exact: true,
        component: <Navigate to={'/'}/>,
    },
    {path: '*', component: <Navigate to={'/'}/>},
];



